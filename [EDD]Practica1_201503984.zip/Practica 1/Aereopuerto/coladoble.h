#ifndef COLADOBLE_H
#define COLADOBLE_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>

//para numeros aleatorios
#include <time.h>

typedef struct Nodo1
{
    int id;
    int dimension;
    int pasajero;
    int desabordaje;
    int mantenimiento;
    Nodo1 *siguiente, *anterior;
} Nodo1;

typedef struct ColaDoble
{
    Nodo1 *inicio, *fin;
} ColaDoble;

void IniciarAviones(ColaDoble *cola);
bool noAvion(ColaDoble *cola);
void InsertarAvion(ColaDoble *cola, int dato);
void EliminarAvion(ColaDoble *cola);
void EliminarAvion_all(ColaDoble *cola);
QString MostrarAvion(ColaDoble *cola);
Nodo1 *primerAvion(ColaDoble *cola);
void Escribir_Avion_1(ColaDoble *cola);
void Escribir_Avion_2(ColaDoble *cola);


#endif // COLADOBLE_H
