#include "colarevision.h"

Nodo4::Nodo4()
{
    siguiente = NULL;
}

ColaRegistro::ColaRegistro()
{
    this->cantidad = 0;
    this->inicio = NULL;
    this->fin = NULL;
}

bool ColaRegistro::noRegistro()
{
    return (this->inicio == NULL);
}

int ColaRegistro::cantRegistro()
{
    return this->cantidad;
}

void ColaRegistro::insertarColaRegistro(int id, int cantMaleta, int cantDoc, int turno)
{
    Nodo4 *nuevo = new Nodo4();
    nuevo->id = id;
    nuevo->cantMaleta = cantMaleta;
    nuevo->cantDoc = cantDoc;
    nuevo->turno = turno;

    if(noRegistro())
    {
        inicio = nuevo;
        fin = nuevo;
        nuevo->siguiente = NULL;
    }
    else
    {
        this->fin->siguiente = nuevo;
        this->fin = nuevo;
        fin->siguiente = NULL;
    }
    cantidad++;
}


void ColaRegistro::EliminarColaRegistro()
{
    if(noRegistro())
    {
        //esta vacia
        this->cantidad = 0;
    }
    else
    {
        Nodo4 *temp = inicio;
        inicio = inicio->siguiente;
        delete temp;
        cantidad--;
    }
}

int ColaRegistro::restarTurno()
{
    inicio->turno = inicio->turno-1;
    return inicio->turno;
}

QString ColaRegistro::MostrarColaRegistro()
{
    QString escribir = "";
    Nodo4 *aux = inicio;

    if(noRegistro())
    {
        escribir = "esta vacia";
    }
    else
    {
        while(aux != NULL)
        {
           escribir += QString::number(aux->id) + "  " +QString::number(aux->cantMaleta)+"  " +QString::number(aux->cantDoc)+"  " +QString::number(aux->turno)+ "\n";
           aux = aux->siguiente;
        }
    }
    return escribir;
}

Nodo4 *ColaRegistro::primerPasajeroRegistro()
{
    return this->inicio;
}

