#ifndef PILA_H
#define PILA_H


#include <nodo.h>
#include <QString>

class Pila
{
private:

public:
    Nodo *cabeza;

    Pila();
    bool estaVacio();
    void Insertar(int val);
    void Mostrar();
    void Eliminar();
    void Graficar();
    void crearHTML();
};

#endif // PILA_H
