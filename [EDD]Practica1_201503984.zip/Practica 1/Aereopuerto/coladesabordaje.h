#ifndef COLADESABORDAJE_H
#define COLADESABORDAJE_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>

//para numeros aleatorios
#include <time.h>

typedef struct Nodo2
{
    int id;
    int cantMaleta;
    int cantDoc;
    int turno;
    Nodo2 *siguiente;
} Nodo2;

typedef struct ColaDesabordaje
{
    int cantPasajero;
    Nodo2 *inicio, *fin;
} ColaDesabordaje;

void IniciarDesabordaje(ColaDesabordaje *cola);
bool noPasajero(ColaDesabordaje *cola);
int CantidadPasajeroDes(ColaDesabordaje *cola);
Nodo2 *InsertarPasajero(ColaDesabordaje *cola, int dato);
void EliminarPasajero(ColaDesabordaje *cola);
void EliminarPasajero_all(ColaDesabordaje *cola);
QString MostrarPasajero(ColaDesabordaje *cola);

Nodo2 *primerPasajeroD(ColaDesabordaje *cola);

void Escribir_Desabordaje_1(ColaDesabordaje *cola);
void Escribir_Desabordaje_2(ColaDesabordaje *cola);

#endif // COLADESABORDAJE_H
