#ifndef NODO_H
#define NODO_H

#include <iostream>
using namespace std;

#include <fstream>
#include <stdlib.h>

struct Nodo
{
private:
    int valor;
    Nodo *siguiente;
public:
    Nodo(int val);

    int getDato();
    void setDato(int val);
    Nodo *getSiguiente();
    void setSiguiente(Nodo *sig);
};

#endif // NODO_H
