#include "pila.h"

Pila::Pila()
{
    cabeza = NULL;
}

bool Pila::estaVacio()
{
    return (cabeza == NULL);
}

void Pila::Insertar(int val)
{
    Nodo *nuevo = new Nodo(val);
    nuevo->setSiguiente(cabeza);
    cabeza = nuevo;
}

void Pila::Mostrar()
{
    Nodo *aux = cabeza;
    if(estaVacio()){
        cout << "La pila esta Vacia."<< endl;
    }else{
        while(aux != NULL){
            cout << aux->getDato() << endl;
            aux = aux->getSiguiente();
        }
    }
}

void Pila::Eliminar()
{
    if(estaVacio()){
        cout << "La pila esta Vacia."<< endl;
    }else{
        Nodo *temp = cabeza;
        cabeza = cabeza->getSiguiente();
        delete temp;
    }
}

void Pila::Graficar()
{
    Nodo *aux = cabeza;
    ofstream Archivo;
    Archivo.open("Pila.txt");
    if(Archivo.fail()){
        exit(1);
    }

    if(estaVacio())
    {
        cout << "La pila esta Vacia."<< endl;
    }else{
        Archivo << "digraph g{rankdir=LR;" << endl;
        while(aux != NULL){
            Archivo<< "\"" << aux << "\""<< "[label=" << aux->getDato() <<",shape=diamond,style=filled,color=salmon];" << endl;
            aux = aux->getSiguiente();
        }
        aux = cabeza;
        while(aux->getSiguiente() != NULL){
            Archivo <<  "\"" << aux << "\""<< " -> " <<  "\"" << aux->getSiguiente() << "\""<< ";" << endl;
            aux = aux->getSiguiente();
        }

        Archivo << "}";
        Archivo.close();

        system("dot -Tpng Pila.txt -o PILA.png");
    }
}

void Pila::crearHTML()
{
    ofstream Escribir;
    Escribir.open("pagina.html");

    if(Escribir.fail()){
        exit(1);
    }

    Escribir << "<HTML>"<<endl;
    Escribir << "<HEADER></HEADER>"<<endl;
    Escribir << "<BODY background = PILA.png ></BODY>" << endl;
    Escribir << "</HTML>";

    Escribir.close();
}

