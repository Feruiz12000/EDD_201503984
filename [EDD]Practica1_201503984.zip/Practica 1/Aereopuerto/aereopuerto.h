#ifndef AEREOPUERTO_H
#define AEREOPUERTO_H

#include <QMainWindow>

namespace Ui {
class Aereopuerto;
}

class Aereopuerto : public QMainWindow
{
    Q_OBJECT

public:
    explicit Aereopuerto(QWidget *parent = 0);
    ~Aereopuerto();

private slots:
    void on_btnSig_clicked();

    void on_pushButton_clicked();

private:
    Ui::Aereopuerto *ui;
};

#endif // AEREOPUERTO_H
