#include "ld_escritorios.h"

Nodo6::Nodo6(int dato)
{
    this->id = dato;
    this->letra = char(dato);
    this->siguiente = NULL;
    this->anterior = NULL;
}

ListaDoble::ListaDoble()
{
    cantidad = 0;
    this->inicio = NULL;
    this->fin = NULL;
}

bool ListaDoble::noEscritorio()
{
    return (this->inicio == NULL);
}

void ListaDoble::InsertarEscritorio(int dato)
{

        bool bandera = true;
        Nodo6 *atras = inicio;
        Nodo6 *adelante = inicio;
        Nodo6 *nuevo = new Nodo6(dato+64);

        if(noEscritorio())
        {
            this->inicio = nuevo;
            this->fin = nuevo;
            nuevo->siguiente = NULL;
            nuevo->anterior = NULL;
        }
        else
        {
            while(adelante != NULL && bandera)
            {
                if(nuevo->id <= adelante->id)
                {
                    if(adelante == inicio){
                        adelante->anterior = nuevo;
                        nuevo->siguiente = adelante;
                        inicio = nuevo;
                        bandera = false; //-----------------------bandera
                    }
                    else
                    {
                        nuevo->siguiente = adelante;
                        nuevo->anterior = atras;
                        adelante->anterior = nuevo;
                        atras->siguiente = nuevo;
                        bandera = false; //-----------------------bandera
                    }
                }
                else if(adelante == fin)
                {
                    fin->siguiente = nuevo;
                    nuevo->anterior = fin;
                    nuevo->siguiente = NULL;
                    fin = nuevo;
                    bandera = false; //-----------------------bandera
                }

                atras = adelante;
                adelante = adelante->siguiente;
            }
        }

        cantidad++;
}

void ListaDoble::EliminarListaDoble()
{
    for(int i = 0; i< cantidad; i++)
    {
        if(noEscritorio())
        {
            //la lista esta vacia
        }
        else
        {
            Nodo6 *temp = inicio;

            if(temp == fin){
                fin = NULL;
                inicio = NULL;
            }else{
                inicio = inicio->siguiente;
                inicio->anterior = NULL;
                temp->siguiente = NULL;
                delete temp;
            }
        }
    }
    cantidad = 0;
}



//UTILIZAR COLA Y PILA

void ListaDoble::VerificarEscritorio(CircularDoble *cd)
{
    Nodo6 *aux = inicio;

    while(aux != NULL)
    {
        if(!aux->Pasajero->noRegistro())
        {
            if(aux->Pasajero->restarTurno() == 0)
            {
                for(int i=0; i< aux->Pasajero->inicio->cantMaleta; i++)
                {
                    EliminarMaleta(cd);
                }

                aux->Pasajero->EliminarColaRegistro();
                aux->Documento->VaciarPila();

                if(!aux->Pasajero->noRegistro())
                {
                    for(int i = 0; i < aux->Pasajero->inicio->cantDoc ; i++)
                    {
                        aux->Documento->InsertarDocumento();
                    }
                }
            }
        }

        aux = aux->siguiente;
    }
}

bool ListaDoble::addColaEscritorio(int id, int cantMaleta, int cantDoc, int turno)
{
         Nodo6 *temp = inicio;
         bool bandera = false;

        //AgregarPasajeros a la cola

         while(temp != NULL && bandera == false)
         {
             if(temp->Pasajero->noRegistro())
             {
                     temp->Pasajero->insertarColaRegistro(id, cantMaleta, cantDoc, turno);
                     for(int i=0; i<cantDoc; i++)
                     {
                         temp->Documento->InsertarDocumento();
                     }
                     bandera = true;
                     return bandera;
             }
             else
             {
                 if(temp->Pasajero->cantidad < 11)
                 {
                     temp->Pasajero->insertarColaRegistro(id, cantMaleta, cantDoc, turno);
                     bandera = true;
                     return bandera;
                 }
                 else
                 {
                     temp = temp->siguiente;
                 }
             }

         }

          return bandera;
}

QString ListaDoble::MostrarCola()
{
    QString escribir = "";
    Nodo6 *temp = inicio;
    while (temp != NULL) {
        escribir += "Escritorios : " + QString::number(temp->Pasajero->cantRegistro())+"\n";
        temp = temp->siguiente;
    }
    return escribir;
}

QString ListaDoble::MostrarEscritorio()
{
    QString escribir = "";
    Nodo6 *aux = inicio;

    if(noEscritorio())
    {
        escribir = "esta vacia";
    }
    else
    {
        escribir += "----- Escritorios de Registro -----\n\n";

        while(aux != NULL)
        {
            if(aux->Pasajero->cantidad == 10){
                escribir += "Escritorio ";
                escribir += aux->letra;
                escribir += " lleno\n";
            }
            else
            {
                escribir += "Escritorio ";
                escribir += aux->letra;
                escribir += " libre\n";
            }

            if(aux->Pasajero->noRegistro()){
                escribir += "   Pasajero atendido: ninguno\n";
                escribir += "   Turnos restantes: 0\n";
                escribir += "   Cantidad de docuementos: 0\n\n";
            }
            else
            {
                escribir += "   Pasajero atendido: Pasajero "+QString::number(aux->Pasajero->inicio->id)+"\n";
                escribir += "   Turnos restantes: "+QString::number(aux->Pasajero->inicio->turno)+"\n";
                escribir += "   Cantidad de docuementos:  "+QString::number(aux->Pasajero->inicio->cantDoc)+"\n\n";
            }

           aux = aux->siguiente;
        }
    }
    return escribir;
}

void ListaDoble::Escribir_Escritorio_1()
{
    fstream escribirArchivo;
    Nodo6 *temp = inicio;

    if(noEscritorio())
    {
        //No hay escritorios
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open()){
            while(temp != NULL)
            {
                if(temp == inicio)
                {
                    escribirArchivo << "\nrank=same{\"" << temp << "\"";
                }
                else
                {
                    escribirArchivo << ", \"" << temp << "\"";
                }

                temp = temp->siguiente;
            }
            escribirArchivo << "}\n\n";

            temp = inicio;
            Nodo4 *temp1 = temp->Pasajero->inicio;
            Nodo5 *temp2 = temp->Documento->inicio;

            while(temp != NULL)
            {
                if(temp->Pasajero->inicio != NULL)
                {
                    escribirArchivo << "\"" << temp << "\"[label= \"Escritorio " << temp->letra << "\nPasajero "<< temp->Pasajero->inicio->id <<" \n Turnos: " << temp->Pasajero->inicio->turno << "\nDocumentos: "<< temp->Pasajero->inicio->cantDoc <<"\", image = \"Escritorio.jpg\" , fontsize = 10 ];\n";
                }
                else
                {
                    escribirArchivo << "\"" << temp << "\"[label= \"Escritorio\n" << temp->letra << "\", image = \"Escritorio.jpg\"];\n";
                }

                temp1 = temp->Pasajero->inicio;
                temp2 = temp->Documento->inicio;
                if(!temp->Pasajero->noRegistro()){

             //CAMBIO 1
                    temp1 = temp1->siguiente;
                    while(temp1 != NULL)
                    {
                        escribirArchivo << "\"" << temp1 << "\"[label= \"Pasajero " << temp1->id << "\", image = \"pasajero2.png\"];\n";
                        temp1 = temp1->siguiente;
                    }

                    while(temp2 != NULL)
                    {
                        escribirArchivo << "\"" << temp2 << "\"[label= \"Documento " << temp2->id << "\", image = \"Documento.jpg\"];\n";
                        temp2 = temp2->siguiente;
                    }
                }

                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}

void ListaDoble::Escribir_Escritorio_2()
{
    fstream escribirArchivo;
    Nodo6 *temp = inicio;

    if(noEscritorio())
    {
        //No hay escritorios
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        Nodo4 *temp1 = inicio->Pasajero->inicio;
        Nodo5 *temp2 = inicio->Documento->inicio;
        int cont = 1;

        while(temp != NULL)
            {
                if(temp->siguiente != NULL)
                {
                    escribirArchivo << "\"" << temp << "\" -> \"" << temp->siguiente << "\"; \n";
                    escribirArchivo << "\"" << temp->siguiente << "\" -> \"" << temp << "\"; \n";
                }

                temp1 = temp->Pasajero->inicio;
                temp2 = temp->Documento->inicio;

                if(!temp->Pasajero->noRegistro())
                {
                    escribirArchivo << "subgraph cluster_A" << cont << "{ label=\"Pasajeros en cola\"; color=red;\n";


            //CAMBIO 2
                    if(temp1->siguiente != NULL){
                        escribirArchivo << "\"" << temp << "\" -> \"" << temp1->siguiente << "\"; \n";
                    }
                    escribirArchivo << "\"" << temp << "\" -> \"" << temp2 << "\"; \n";

             //CAMBIO 3
                    temp1 = temp1->siguiente;
                    while(temp1->siguiente != NULL)
                    {
                        escribirArchivo << "\"" << temp1 << "\" -> \"" << temp1->siguiente << "\"; \n";
                        temp1 = temp1->siguiente;
                    }

                    while(temp2->siguiente != NULL)
                    {
                        escribirArchivo << "\"" << temp2 << "\" -> \"" << temp2->siguiente << "\"; \n";
                        temp2 = temp2->siguiente;
                    }
                    escribirArchivo <<"}"<< endl;
                }

                temp = temp->siguiente;
                cont++;

            }

            escribirArchivo.close();
        }
}





/*



        Nodo6 *nuevo = new Nodo6(dato+64);

        if(noEscritorio())
        {
            this->inicio = nuevo;
            this->fin = nuevo;
            nuevo->siguiente = NULL;
            nuevo->anterior = NULL;
        }
        else
        {
            fin->siguiente = nuevo;
            nuevo->anterior = fin;
            nuevo->siguiente = NULL;
            fin = nuevo;
        }
        cantidad++;


*/
