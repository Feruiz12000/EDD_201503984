#ifndef PILADOCUMENTO_H
#define PILADOCUMENTO_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>


struct Nodo5
{

public:
    int id;
    Nodo5 *siguiente;

    Nodo5();
};

struct PilaDocumento
{

public:
    int cantDoc;
    Nodo5 *inicio;

    PilaDocumento();

    int cantDocumentos();
    bool noDocumento();
    void InsertarDocumento();
    void VaciarPila();
    QString MostrarPila();
};

#endif // PILADOCUMENTO_H
