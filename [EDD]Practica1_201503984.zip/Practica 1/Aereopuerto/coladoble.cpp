#include "coladoble.h"


void IniciarAviones(ColaDoble *cola)
{
    cola->inicio = NULL;
    cola->fin = NULL;
}

bool noAvion(ColaDoble *cola)
{
    return (cola->inicio == NULL);
}

void InsertarAvion(ColaDoble *cola, int dato)
{
    Nodo1 *nuevo = new Nodo1();

    srand(time(NULL));

    nuevo->id = dato;
    nuevo->dimension = 1+rand()%(4-1);
    switch (nuevo->dimension) {
    case 1://Avion pequeño
        nuevo->pasajero = 5+rand()%(11-5);
        nuevo->desabordaje = 1;
        nuevo->mantenimiento = 1+rand()%(4-1);
        break;
    case 2://Avion Mediano
        nuevo->pasajero = 15+rand()%(26-15);
        nuevo->desabordaje = 2;
        nuevo->mantenimiento = 2+rand()%(5-2);
        break;
    case 3://Avion grande
        nuevo->pasajero = 30+rand()%(41-30);
        nuevo->desabordaje = 3;
        nuevo->mantenimiento = 3+rand()%(7-3);
        break;
    }

    if(noAvion(cola))
    {
        cola->inicio = nuevo;
        nuevo->siguiente = NULL;
        nuevo->anterior = NULL;
        cola->fin = nuevo;
    }
    else
    {
        cola->fin->siguiente = nuevo;
        nuevo->siguiente = NULL;
        nuevo->anterior = cola->fin;
        cola->fin = nuevo;
    }
}



QString MostrarAvion(ColaDoble *cola)
{
    QString cadena="";

    if(noAvion(cola))
    {
        //la lista esta vacia
    }
    else
    {
           cadena += "\narribo avión "+QString::number(cola->fin->id)+"\n";
           cadena += "dimension: "+QString::number(cola->fin->dimension)+"\n";
           cadena += "pasajeros: "+QString::number(cola->fin->pasajero)+"\n";
           cadena += "desabordaje: "+QString::number(cola->fin->desabordaje)+"\n";
           cadena += "mantenimiento: "+QString::number(cola->fin->mantenimiento)+"\n";
    }
    return cadena;
}

void EliminarAvion(ColaDoble *cola)
{
    if(noAvion(cola)){
       //no hay aviones
    }
    else{

        Nodo1 *temp = cola->inicio;

        if(temp == cola->fin){
            cola->inicio = cola->fin = NULL;
        }
        else
        {
            cola->inicio = temp->siguiente;
            cola->inicio->anterior = NULL;
            cola->inicio->desabordaje--;
            delete temp;
        }
    }
}

Nodo1 *primerAvion(ColaDoble *cola)
{
    return cola->inicio;
}

void Escribir_Avion_1(ColaDoble *cola)
{
    fstream escribirArchivo;
    Nodo1 *temp = cola->inicio;

    if(noAvion(cola))
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open()){
            while(temp != NULL)
            {
                switch (temp->dimension) {
                case 1:
                    escribirArchivo << "\"" << temp << "\"[label= \"avión " << temp->id << "\", image = \"avionPeque.jpg\"];\n";
                    break;
                case 2:
                    escribirArchivo << "\"" << temp << "\"[label= \"avión " << temp->id << "\", image = \"avionMediano.jpg\"];\n";
                    break;
                case 3:
                    escribirArchivo << "\"" << temp << "\"[label= \"avión " << temp->id <<"\", image = \"avionGrande.jpg\"];\n";
                    break;
                }
                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}

void Escribir_Avion_2(ColaDoble *cola)
{
    fstream escribirArchivo;
    Nodo1 *temp = cola->inicio;

    if(noAvion(cola))
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open())
        {
            while(temp->siguiente != NULL)
            {
                escribirArchivo << "\"" << temp << "\" -> \"" << temp->siguiente << "\"; \n";
                escribirArchivo << "\"" << temp->siguiente << "\" -> \"" << temp << "\"; \n";
                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}

void EliminarAvion_all(ColaDoble *cola)
{
        while(!noAvion(cola))
        {
            EliminarAvion(cola);
        }
}
