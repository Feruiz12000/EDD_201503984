#ifndef LD_ESCRITORIOS_H
#define LD_ESCRITORIOS_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>


#include <colarevision.h>
#include <piladocumento.h>

#include <circulardoble.h>

struct Nodo6
{
public:
    int id;
    char letra;
    ColaRegistro *Pasajero = new ColaRegistro();
    PilaDocumento *Documento = new PilaDocumento();
    Nodo6 *siguiente, *anterior;
    Nodo6(int dato);
};


struct ListaDoble
{
public:

    int cantidad;
    Nodo6 *inicio, *fin;

    ListaDoble();
    bool noEscritorio();
    void InsertarEscritorio(int dato);
    void EliminarListaDoble();
    QString MostrarEscritorio();

    void VerificarEscritorio(CircularDoble *cd);
    bool addColaEscritorio(int id, int cantMaleta, int cantDoc, int turno);
    QString MostrarCola();

    void Escribir_Escritorio_1();
    void Escribir_Escritorio_2();
};



#endif // LD_ESCRITORIOS_H
