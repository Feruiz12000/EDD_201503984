#ifndef CIRCULARDOBLE_H
#define CIRCULARDOBLE_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>



typedef struct Nodo3
{
    int id;
    Nodo3 *siguiente, *anterior;
} Nodo3;

typedef struct CircularDoble
{
    int cont;
    Nodo3 *inicio, *fin;
} CircularDoble;

void IniciarMaleta(CircularDoble *cd);
bool noMaleta(CircularDoble *cd);
void InsertarMaleta(CircularDoble *cd, int dato);
void EliminarMaleta(CircularDoble *cd);
void EliminarMaleta_all(CircularDoble *cd);
QString MostrarMaleta(CircularDoble *cd);

void Escribir_Maleta_1(CircularDoble *cd);
void Escribir_Maleta_2(CircularDoble *cd);


#endif // CIRCULARDOBLE_H
