#ifndef LISTAESTACIONES_H
#define LISTAESTACIONES_H


#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>

#include <colamantenimiento.h>

struct Nodo8
{
    int id;
    colaMantenimiento *cl = new colaMantenimiento();
    Nodo8 *siguiente;
    Nodo8(int id);
};

struct listaEstacion
{
    int contador;
    Nodo8 *inicio, *fin;
    listaEstacion();

    bool noEstacion();
    void InsertarEstacion(int id);
    void EliminarEstacion();
    void EliminarTodo();
    QString MostrarEstacion();

    bool addAvionMantenimiento(colaMantenimiento *cola);
    void VerificarAvionMantenimiento();

    void Escribir_Estacion_1();
    void Escribir_Estacion_2();
};

#endif // LISTAESTACIONES_H
