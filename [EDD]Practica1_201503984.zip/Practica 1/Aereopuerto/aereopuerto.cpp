#include "aereopuerto.h"
#include "ui_aereopuerto.h"

#include <iostream>
using namespace std;

#include <fstream>
#include <stdlib.h>

#include <coladoble.h>
#include <coladesabordaje.h>
#include <circulardoble.h>
#include <listaestaciones.h>

#include <ld_escritorios.h>

Aereopuerto::Aereopuerto(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Aereopuerto)
{
    ui->setupUi(this);
}

Aereopuerto::~Aereopuerto()
{
    delete ui;
}




//variables
int contAvion = 1;
int contDesabordaje = 1;
int contMaleta = 1;
QString escribir = "";


//CREACION DE LISTAS
ColaDoble *cl = new ColaDoble();
ColaDesabordaje *cld = new ColaDesabordaje();
CircularDoble *cd = new CircularDoble();
ListaDoble *listaD = new ListaDoble();

colaMantenimiento *clMant = new colaMantenimiento();
listaEstacion *l_Estacion = new listaEstacion();


//Variables de entrada
int cant_Aviones;
int cant_Pasos;
int cant_Escritorios;
int cant_Estaciones;
int var_1;



void Escribir_en_el_archivo(){
    ofstream crearArchivo;
    crearArchivo.open("Graph.txt");
    if(crearArchivo.fail()){ exit(1);}
    crearArchivo << "digraph g{ node[ fontname = \"Verdana\", style=filled, color=\"#FFFFFF\", fontcolor=\"#000000\", labelloc = b, shape=square, margin = 0, color = black, style=bold, fontsize = 10, fixedsize = true, width =1  ];"<< endl;
    crearArchivo.close();

    //metodos para escribir
    Escribir_Avion_1(cl);
    Escribir_Desabordaje_1(cld);
    Escribir_Maleta_1(cd);
    listaD->Escribir_Escritorio_1();
    clMant->Escribir_ColaMantenimiento_1();
    l_Estacion->Escribir_Estacion_1();

    Escribir_Avion_2(cl);
    Escribir_Desabordaje_2(cld);
    Escribir_Maleta_2(cd);
    listaD->Escribir_Escritorio_2();
    clMant->Escribir_ColaMantenimiento_2();
    l_Estacion->Escribir_Estacion_2();

    fstream escribirArchivo;
    escribirArchivo.open("Graph.txt", ios::app);
    if(escribirArchivo.is_open()){ escribirArchivo << "}"; escribirArchivo.close(); }
    system("dot -Tpng Graph.txt -o Imagen.png");
}


void Aereopuerto::on_btnSig_clicked()
{
    if(contAvion <= cant_Pasos )
    {

   //**************************** Escribir en consola ****************************
   //*****************************************************************************

            escribir += "******** Turno "+QString::number(contAvion)+" ********";


//Insertar avion
            if(contAvion <= cant_Aviones)
            {
                InsertarAvion(cl, contAvion);
                escribir += MostrarAvion(cl);
            }

            //Verificar si hay aviones en la lista
            if(!noAvion(cl))
            {
                //****************************INICIO+****************************

                if(primerAvion(cl)->desabordaje != 0){
                    primerAvion(cl)->desabordaje--;
                }
                else
                {

            //insertar Pasajeros y Maletas
                        Nodo1 *avionElim = primerAvion(cl);

                        escribir += "avión desabordando: "+QString::number(avionElim->id)+"\n";

            //insertar avion a la cola de mantenimiento
                        clMant->addAvionMant(avionElim->id, avionElim->dimension, avionElim->pasajero, avionElim->desabordaje, avionElim->mantenimiento);

            //insertar pasajeros y maletas
                        int cantpas = avionElim->pasajero;
                        for(int i = 0; i< cantpas;i++)
                        {
                            //PASAJERO
                            Nodo2 *nuevoPasajero = InsertarPasajero(cld, contDesabordaje);

                            //MALETAS
                            for(int i=0;i<nuevoPasajero->cantMaleta;i++){
                                InsertarMaleta(cd, contMaleta);
                                contMaleta++;
                            }
                            contDesabordaje++;
                         }

            //ELiminacion de avion
                        EliminarAvion(cl);
                        //escribir += MostrarPasajero(cld);
                }
                //**************************************FIN*********************************
            }

//AgregarAvion a Mantenimiento
            bool entrar = true;
            l_Estacion->VerificarAvionMantenimiento();

            while(entrar && !clMant->noAvion())
            {
               entrar = l_Estacion->addAvionMantenimiento(clMant);
            }

//realizar cola para los escritorios
            bool bandera = true;
            QString cadena = "";

                    listaD->VerificarEscritorio(cd); //Verifica a los primeros de la fila
                    while(bandera && !noPasajero(cld)){
                        Nodo2 *pasajero = primerPasajeroD(cld);
                        bandera = listaD->addColaEscritorio(pasajero->id, pasajero->cantMaleta, pasajero->cantDoc, pasajero->turno);
                        if(bandera)
                        {
                             EliminarPasajero(cld);
                        }
                    }

            escribir += listaD->MostrarEscritorio();
            escribir += l_Estacion->MostrarEstacion();
            escribir += "Cant. de maletas: "+ QString::number(cd->cont)+"\n";
            escribir += "Turnos restantes: "+QString::number(cant_Pasos - contAvion)+"\n";

            escribir += "***** Fin de Turno "+QString::number(contAvion)+" *****\n";
            ui->consola->setText(escribir);
        //*****************************************************************************


//Crear Graph.txt y Imagen.png

            Escribir_en_el_archivo();

//MOSTRAR IMAGEN
                QPixmap img1("Imagen.png");
                ui->txtImg->setPixmap(img1);
                ui->txtImg->adjustSize();
//PROGRESO DE LA BARRA
                ui->progreso->setValue(contAvion);
                contAvion++;
    }
    else
    {
        ui->cantAviones->setValue(1);
        ui->cantEscritorios->setValue(1);
        ui->cantEstaciones->setValue(1);
        ui->cantPasos->setValue(1);
        ui->ventana->setCurrentIndex(1);
    }
}



void LimpiarVariables(){
    //variables
    contAvion = 1;
    contDesabordaje = 1;
    contMaleta = 1;
    escribir = "";
    var_1 = 0;

    /*EliminarAvion_all(cl);
    EliminarPasajero_all(cld);
    EliminarMaleta_all(cd);*/

    listaD->EliminarListaDoble();
    clMant->EliminarTodo();
    l_Estacion->EliminarTodo();
}


void Aereopuerto::on_pushButton_clicked()
{
    LimpiarVariables();

    bool escritorio=true;

    try {

        cant_Aviones = ui->cantAviones->value();
        cant_Escritorios = ui->cantEscritorios->value();;
        cant_Estaciones = ui->cantEstaciones->value();;
        cant_Pasos = ui->cantPasos->value();;

        IniciarDesabordaje(cld);
        IniciarAviones(cl);
        IniciarMaleta(cd);

        while(escritorio)
        {
            if(cant_Escritorios <= 26)
            {
                for(int i = 1; i<= cant_Escritorios ; i++){
                    listaD->InsertarEscritorio(i);
                }
                escritorio = false;
            }
            else if(cant_Escritorios > 26)
            {
                cant_Escritorios = cant_Escritorios-26;
                for(int i = 1; i<= 26 ; i++){
                    listaD->InsertarEscritorio(i);
                }
            }
        }

        for(int i=1;i<= cant_Estaciones; i++)
        {
            l_Estacion->InsertarEstacion(i);
        }


        Escribir_en_el_archivo();
        QPixmap img2("Imagen.png");
        ui->txtImg->setPixmap(img2);
        ui->txtImg->adjustSize();

        ui->progreso->setValue(0);
        ui->consola->setText("");


        ui->progreso->setMaximum(cant_Pasos);

        ui->ventana->setCurrentIndex(0);

    } catch (exception e) {}
}

