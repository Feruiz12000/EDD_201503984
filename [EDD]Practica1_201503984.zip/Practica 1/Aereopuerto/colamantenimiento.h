#ifndef COLAMANTENIMIENTO_H
#define COLAMANTENIMIENTO_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>

struct Nodo7
{
    int id;
    int dimension;
    int pasajero;
    int desabordaje;
    int mantenimiento;
    Nodo7 *siguiente;
    Nodo7(int id, int dimension, int pasajero, int desabordaje, int mantenimiento);
};

struct colaMantenimiento
{
    Nodo7 *inicio, *fin;
    colaMantenimiento();
    bool noAvion();
    void addAvionMant(int id, int dimension, int pasajero, int desabordaje, int mantenimiento);
    void deleteAvionMant();
    void EliminarTodo();
    //Nodo7 firstAvionMant();
    int restarMantenimiento();

    void Escribir_ColaMantenimiento_1();
    void Escribir_ColaMantenimiento_2();
};


#endif // COLAMANTENIMIENTO_H
