#include "colamantenimiento.h"



Nodo7::Nodo7(int id, int dimension, int pasajero, int desabordaje, int mantenimiento)
{
    this->id = id;
    this->dimension = dimension;
    this->pasajero = pasajero;
    this->desabordaje = desabordaje;
    this->mantenimiento = mantenimiento;
    this->siguiente = NULL;
}

colaMantenimiento::colaMantenimiento()
{
    inicio = NULL;
    fin = NULL;
}

bool colaMantenimiento::noAvion()
{
    return (inicio == NULL);
}

void colaMantenimiento::addAvionMant(int id, int dimension, int pasajero, int desabordaje, int mantenimiento)
{
    Nodo7 *nuevo = new Nodo7(id, dimension, pasajero, desabordaje, mantenimiento);
    if(noAvion())
    {
        inicio = fin = nuevo;
    }
    else
    {
        fin->siguiente = nuevo;
        fin = nuevo;
    }
}

void colaMantenimiento::deleteAvionMant()
{
    if(noAvion())
    {
        //no hay ningun avion
    }
    else
    {
        Nodo7 *temp = inicio;
        inicio = inicio->siguiente;
        delete temp;
    }
}

void colaMantenimiento::EliminarTodo()
{
    while(inicio != NULL){
        deleteAvionMant();
    }
}

/*Nodo7 colaMantenimiento::firstAvionMant()
{
    return this->inicio;
}*/

int colaMantenimiento::restarMantenimiento()
{
    inicio->mantenimiento--;
    return inicio->mantenimiento;
}



void colaMantenimiento::Escribir_ColaMantenimiento_1()
{
    fstream escribirArchivo;
    Nodo7 *temp = inicio;

    if(noAvion())
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open()){
            while(temp != NULL)
            {
                switch (temp->dimension) {
                case 1:
                    escribirArchivo << "\"" << temp << "\"[label= \"avión " << temp->id << "\", image = \"avionPeque.jpg\"];\n";
                    break;
                case 2:
                    escribirArchivo << "\"" << temp << "\"[label= \"avión " << temp->id << "\", image = \"avionMediano.jpg\"];\n";
                    break;
                case 3:
                    escribirArchivo << "\"" << temp << "\"[label= \"avión " << temp->id <<"\", image = \"avionGrande.jpg\"];\n";
                    break;
                }
                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}

void colaMantenimiento::Escribir_ColaMantenimiento_2()
{
    fstream escribirArchivo;
    Nodo7 *temp = inicio;

    if(noAvion())
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open())
        {
            escribirArchivo << "subgraph cluster_Mantenimiento{ label=\"Pasajeros Desbordando\"; color=green;\n";
            while(temp->siguiente != NULL)
            {
                escribirArchivo << "\"" << temp << "\" -> \"" << temp->siguiente << "\"; \n";
                temp = temp->siguiente;
            }
            escribirArchivo << "}\n";
            escribirArchivo.close();
        }
    }
}


