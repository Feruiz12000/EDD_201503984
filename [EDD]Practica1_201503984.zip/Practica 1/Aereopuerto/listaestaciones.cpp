#include "listaestaciones.h"

Nodo8::Nodo8(int id)
{
    this->id = id;
    this->siguiente = NULL;
}

listaEstacion::listaEstacion()
{
    this->inicio = NULL;
    this->fin = NULL;
    this->contador = 0;
}

bool listaEstacion::noEstacion()
{
    return (inicio == NULL);
}

void listaEstacion::InsertarEstacion(int id)
{
    Nodo8 *nuevo = new Nodo8(id);
    if(noEstacion())
    {
        inicio = fin = nuevo;
    }
    else
    {
        fin->siguiente = nuevo;
        fin = nuevo;
    }
}

void listaEstacion::EliminarEstacion()
{
    if(noEstacion())
    {
        //No hay estaciones en la lista
    }
    else
    {
        Nodo8 *temp = inicio;
        inicio = inicio->siguiente;
        delete temp;
    }
}

void listaEstacion::EliminarTodo()
{
    while(inicio != NULL){
        EliminarEstacion();
    }
}

QString listaEstacion::MostrarEstacion()
{
    QString cadena = "";
    Nodo8 *aux = inicio;

    if(noEstacion())
    {
      //esta vacio
    }
    else
    {
        cadena += "\n+++ Estaciones de Servicio +++\n\n";
        while(aux != NULL)
        {
            if(aux->cl->noAvion())
            {
                cadena += "Estacion "+QString::number(aux->id)+": libre\n";
                cadena += " Avión en mantenimiento: ninguno\n";
                cadena += " Turnos restantes: 0\n\n";
            }
            else
            {
                cadena += "Estacion "+QString::number(aux->id)+": ocupado\n";
                cadena += " Avión en mantenimiento: Avion "+QString::number(aux->cl->inicio->id)+"\n";
                cadena += " Turnos restantes: "+QString::number(aux->cl->inicio->mantenimiento)+"\n\n";
            }
            aux = aux->siguiente;
        }
        cadena += "\n+++++++++++++++++++++++++++\n\n";
    }
    return cadena;
}

bool listaEstacion::addAvionMantenimiento(colaMantenimiento *cola)
{
    Nodo8 *temp = inicio;

    while(temp != NULL)
    {
        if(temp->cl->noAvion())
        {
            temp->cl->addAvionMant(cola->inicio->id,cola->inicio->dimension, cola->inicio->pasajero, cola->inicio->desabordaje, cola->inicio->mantenimiento);
            cola->deleteAvionMant();
            return true;
        }
        temp = temp->siguiente;
    }

    return false;
}

void listaEstacion::VerificarAvionMantenimiento()
{
    Nodo8 *temp = inicio;
    if(inicio != NULL)
    {
        while(temp != NULL)
        {
            if(!temp->cl->noAvion())
            {
                if(temp->cl->restarMantenimiento() == 0)
                {
                    temp->cl->deleteAvionMant();
                }
            }
            temp = temp->siguiente;
        }
    }
}

void listaEstacion::Escribir_Estacion_1()
{
    fstream escribirArchivo;
    Nodo8 *temp = inicio;

    if(noEstacion())
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open()){
            while(temp != NULL)
            {
                if(temp == inicio)
                {
                    escribirArchivo << "\nrank=same{\"" << temp << "\"";
                }
                else
                {
                    escribirArchivo << ", \"" << temp << "\"";
                }

                temp = temp->siguiente;
            }
            escribirArchivo << "}\n\n";

            temp = inicio;
            while(temp != NULL)
            {
                if(temp->cl->inicio != NULL)
                {
                    try {
                        escribirArchivo << "\"" << temp << "\"[label= \"Estacion " << temp->id << "\nAvión "<< temp->cl->inicio->id <<"\n Turno: " << temp->cl->inicio->mantenimiento << "\", image = \"Estacion.jpg\"];\n";
                    } catch (exception e) {}
                }
                else
                {
                    escribirArchivo << "\"" << temp << "\"[label= \"Estacion " << temp->id << "\", image = \"Estacion.jpg\"];\n";
                }
                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}

void listaEstacion::Escribir_Estacion_2()
{
    fstream escribirArchivo;
    Nodo8 *temp = inicio;

    if(noEstacion())
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open())
        {
            while(temp->siguiente != NULL)
            {
                escribirArchivo << "\"" << temp << "\" -> \"" << temp->siguiente << "\"; \n";
                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}


