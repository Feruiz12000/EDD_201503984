#include "coladesabordaje.h"

void IniciarDesabordaje(ColaDesabordaje *cola)
{
    cola->inicio = NULL;
    cola->fin = NULL;
}

bool noPasajero(ColaDesabordaje *cola)
{
    return (cola->inicio == NULL);
}

Nodo2 *InsertarPasajero(ColaDesabordaje *cola, int dato)
{
    Nodo2 *nuevo = new Nodo2();
    nuevo->id = dato;
    nuevo->cantMaleta = 1+rand()%(5-1);
    nuevo->cantDoc = 1+rand()%(11-1);
    nuevo->turno = 1+rand()%(4-1);

    if(noPasajero(cola))
    {
        cola->inicio = nuevo;
        nuevo->siguiente = NULL;
        cola->fin = nuevo;
    }
    else
    {
        cola->fin->siguiente = nuevo;
        nuevo->siguiente = NULL;
        cola->fin = nuevo;
    }
    cola->cantPasajero++;
    return nuevo;
}


//retorna | NULL | o retorna | Nodo | eliminado
void EliminarPasajero(ColaDesabordaje *cola)
{
    if(noPasajero(cola))
    {
        //esta vacia la lista
    }
    else
    {
        Nodo2 *aux = cola->inicio;
        cola->inicio = cola->inicio->siguiente;
        delete aux;
        cola->cantPasajero--;
    }

}


//Este metodo no nos servira BORRAR
QString MostrarPasajero(ColaDesabordaje *cola)
{
    QString cadena = "";
    Nodo2 *aux = cola->inicio;

    if(noPasajero(cola))
    {
      //esta vacio
    }
    else
    {
        while(aux != NULL)
        {
            cadena += "     pasajero "+QString::number(aux->id)+"\n";
            aux = aux->siguiente;
        }
    }
    return cadena;
}



void Escribir_Desabordaje_1(ColaDesabordaje *cola)
{
    fstream escribirArchivo;
    Nodo2 *temp = cola->inicio;

    if(noPasajero(cola))
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open()){
            while(temp != NULL)
            {
                escribirArchivo << "\"" << temp << "\"[label= \"Pasajero " << temp->id << "\", image = \"pasajero1.jpg\"];\n";
                temp = temp->siguiente;
            }
            escribirArchivo.close();
        }
    }
}

void Escribir_Desabordaje_2(ColaDesabordaje *cola)
{
    fstream escribirArchivo;
    Nodo2 *temp = cola->inicio;

    if(noPasajero(cola))
    {
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);

        if(escribirArchivo.is_open())
        {
            escribirArchivo << "subgraph cluster_Cuadro1{ label=\"Pasajeros Desbordando\"; color=blue;\n";

            while(temp->siguiente != NULL)
            {
                escribirArchivo << "\"" << temp << "\" -> \"" << temp->siguiente << "\"; \n";
                temp = temp->siguiente;
            }
            escribirArchivo << "}" << endl;
            escribirArchivo.close();
        }
    }
}

Nodo2 *primerPasajeroD(ColaDesabordaje *cola)
{
    return cola->inicio;
}

int CantidadPasajeroDes(ColaDesabordaje *cola)
{
    return cola->cantPasajero;
}

void EliminarPasajero_all(ColaDesabordaje *cola)
{
    while(!noPasajero(cola))
    {
        EliminarPasajero(cola);
    }
}
