#ifndef COLAREVISION_H
#define COLAREVISION_H

#include <iostream>
using namespace std;

#include <QString>

//para archivos
#include <fstream>
#include <stdlib.h>

//para numeros aleatorios
#include <time.h>

struct Nodo4
{
public:
    int id;
    int cantMaleta;
    int cantDoc;
    int turno;
    Nodo4 *siguiente;

    Nodo4();
};

struct ColaRegistro
{
public:
    int cantidad;
    Nodo4 *inicio, *fin;
    ColaRegistro();

    bool noRegistro();
    int cantRegistro();
    void insertarColaRegistro(int id, int cantMaleta, int cantDoc, int turno);
    void EliminarColaRegistro();
    int restarTurno();
    QString MostrarColaRegistro();
    Nodo4 *primerPasajeroRegistro();
};


#endif // COLAREVISION_H
