#include "circulardoble.h"


void IniciarMaleta(CircularDoble *cd)
{
    cd->inicio = NULL;
    cd->fin = NULL;
    cd->cont = 0;
}

bool noMaleta(CircularDoble *cd)
{
    return (cd->inicio == NULL);
}

void InsertarMaleta(CircularDoble *cd, int dato)
{
    Nodo3 *nuevo = new Nodo3();
    nuevo->id = dato;

    if(noMaleta(cd))
    {
        nuevo->siguiente = nuevo;
        nuevo->anterior = nuevo;
        cd->inicio = nuevo;
        cd->fin = nuevo;
    }
    else
    {
        nuevo->anterior = cd->fin;
        nuevo->siguiente = cd->inicio;
        cd->inicio->anterior = nuevo;
        cd->fin->siguiente = nuevo;
        cd->fin = nuevo;
    }
    cd->cont++;
}

void EliminarMaleta(CircularDoble *cd)
{
    Nodo3 *aux = cd->inicio;

    if(noMaleta(cd))
    {
        //la lista esta vacia.
    }
    else
    {
        if(cd->cont == 1)
        {
            delete cd->inicio;
        }
        else
        {
            aux->siguiente->anterior = aux->anterior;
            aux->anterior->siguiente = aux->siguiente;
            cd->inicio = aux->siguiente;
            delete aux;
        }
        cd->cont--;
    }
}

void Escribir_Maleta_1(CircularDoble *cd)
{
    fstream escribirArchivo;
    Nodo3 *temp = cd->inicio;

    if(noMaleta(cd)){
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);
        if(escribirArchivo.is_open())
        {
            do{
                escribirArchivo << "\"" << temp << "\"[label= \"Maleta " << temp->id << "\", image = \"Maleta.jpg\"];\n";
                temp = temp->siguiente;
            }while(temp != cd->inicio);
            escribirArchivo.close();
        }
    }
}

void Escribir_Maleta_2(CircularDoble *cd)
{
    fstream escribirArchivo;
    Nodo3 *temp = cd->inicio;

    if(noMaleta(cd)){
        //la lista esta vacia
    }
    else
    {
        escribirArchivo.open("Graph.txt", ios::app);
        if(escribirArchivo.is_open())
        {
            do{
                escribirArchivo << "\"" << temp << "\" -> \"" << temp->siguiente << "\"; \n";
                escribirArchivo << "\"" << temp->siguiente << "\" -> \"" << temp << "\"; \n";
                temp = temp->siguiente;
            }while(temp != cd->inicio);

            escribirArchivo.close();
        }
    }
}

void EliminarMaleta_all(CircularDoble *cd)
{
    while(!noMaleta(cd))
    {
        EliminarMaleta(cd);
    }
}
