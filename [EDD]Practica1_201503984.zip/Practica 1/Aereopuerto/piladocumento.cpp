#include "piladocumento.h"

Nodo5::Nodo5()
{
    this->siguiente = NULL;
}


PilaDocumento::PilaDocumento()
{
     this->cantDoc = 0;
     this->inicio = NULL;
}


int PilaDocumento::cantDocumentos()
{
    return this->cantDoc;
}

bool PilaDocumento::noDocumento()
{
    return (this->inicio == NULL);
}

void PilaDocumento::InsertarDocumento()
{
    this->cantDoc++;
    Nodo5 *nuevo = new Nodo5();
    nuevo->id = cantDoc;

    nuevo->siguiente = this->inicio;
    this->inicio = nuevo;
}

void PilaDocumento::VaciarPila()
{
    if(noDocumento())
    {
        //la lista esta vacia
    }
    else
    {
        Nodo5 *temp = this->inicio;

        while(temp != NULL)
        {
            Nodo5 *aux = this->inicio;
            this->inicio = this->inicio->siguiente;
            temp = this->inicio;
            delete aux;
        }
    }
    this->cantDoc=0;
}

QString PilaDocumento::MostrarPila()
{
    QString escribir = "";
    Nodo5 *aux = inicio;

    if(noDocumento())
    {
        escribir = "esta vacia";
    }
    else
    {
        while(aux != NULL)
        {
           escribir += "PILA: "+ QString::number(aux->id)+"\n";
           aux = aux->siguiente;
        }
    }
    return escribir;
}

