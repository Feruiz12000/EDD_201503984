#include "nodo.h"

Nodo::Nodo(int val)
{
    valor = val;
    siguiente = NULL;
}

int Nodo::getDato()
{
    return valor;
}

void Nodo::setDato(int val)
{
    valor = val;
}

Nodo *Nodo::getSiguiente()
{
    return siguiente;
}

void Nodo::setSiguiente(Nodo *sig)
{
    siguiente = sig;
}
