/********************************************************************************
** Form generated from reading UI file 'aereopuerto.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AEREOPUERTO_H
#define UI_AEREOPUERTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Aereopuerto
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QStackedWidget *ventana;
    QWidget *page;
    QVBoxLayout *verticalLayout_2;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QHBoxLayout *horizontalLayout;
    QScrollArea *scrollArea_2;
    QWidget *scrollAreaWidgetContents_2;
    QVBoxLayout *verticalLayout_3;
    QTextEdit *textEdit_2;
    QLabel *txtImg;
    QTextEdit *textEdit_3;
    QTextEdit *consola;
    QProgressBar *progreso;
    QPushButton *btnSig;
    QWidget *page_2;
    QPushButton *pushButton;
    QSpinBox *cantEstaciones;
    QLabel *label;
    QLabel *label_2;
    QSpinBox *cantEscritorios;
    QLabel *label_3;
    QSpinBox *cantAviones;
    QLabel *label_4;
    QSpinBox *cantPasos;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Aereopuerto)
    {
        if (Aereopuerto->objectName().isEmpty())
            Aereopuerto->setObjectName(QStringLiteral("Aereopuerto"));
        Aereopuerto->resize(643, 469);
        Aereopuerto->setMinimumSize(QSize(643, 469));
        centralWidget = new QWidget(Aereopuerto);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        ventana = new QStackedWidget(centralWidget);
        ventana->setObjectName(QStringLiteral("ventana"));
        ventana->setStyleSheet(QStringLiteral(""));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        verticalLayout_2 = new QVBoxLayout(page);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        scrollArea = new QScrollArea(page);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 605, 318));
        horizontalLayout = new QHBoxLayout(scrollAreaWidgetContents);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        scrollArea_2 = new QScrollArea(scrollAreaWidgetContents);
        scrollArea_2->setObjectName(QStringLiteral("scrollArea_2"));
        scrollArea_2->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QStringLiteral("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 347, 298));
        verticalLayout_3 = new QVBoxLayout(scrollAreaWidgetContents_2);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        textEdit_2 = new QTextEdit(scrollAreaWidgetContents_2);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setEnabled(false);
        textEdit_2->setMaximumSize(QSize(16777215, 2));

        verticalLayout_3->addWidget(textEdit_2);

        txtImg = new QLabel(scrollAreaWidgetContents_2);
        txtImg->setObjectName(QStringLiteral("txtImg"));
        txtImg->setCursor(QCursor(Qt::ArrowCursor));
        txtImg->setStyleSheet(QStringLiteral(""));

        verticalLayout_3->addWidget(txtImg);

        textEdit_3 = new QTextEdit(scrollAreaWidgetContents_2);
        textEdit_3->setObjectName(QStringLiteral("textEdit_3"));
        textEdit_3->setEnabled(false);
        textEdit_3->setMaximumSize(QSize(16777215, 2));

        verticalLayout_3->addWidget(textEdit_3);

        scrollArea_2->setWidget(scrollAreaWidgetContents_2);

        horizontalLayout->addWidget(scrollArea_2);

        consola = new QTextEdit(scrollAreaWidgetContents);
        consola->setObjectName(QStringLiteral("consola"));
        consola->setMaximumSize(QSize(232, 16777215));
        QFont font;
        font.setPointSize(10);
        consola->setFont(font);
        consola->viewport()->setProperty("cursor", QVariant(QCursor(Qt::ArrowCursor)));
        consola->setStyleSheet(QLatin1String("background-color: rgb(0, 0, 0);\n"
"color: #fff;"));
        consola->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        consola->setAutoFormatting(QTextEdit::AutoNone);
        consola->setReadOnly(true);
        consola->setOverwriteMode(false);

        horizontalLayout->addWidget(consola);

        scrollArea->setWidget(scrollAreaWidgetContents);
        consola->raise();
        scrollArea_2->raise();

        verticalLayout_2->addWidget(scrollArea);

        progreso = new QProgressBar(page);
        progreso->setObjectName(QStringLiteral("progreso"));
        progreso->setMinimumSize(QSize(0, 3));
        progreso->setMaximumSize(QSize(16777215, 15));
        progreso->setLayoutDirection(Qt::LeftToRight);
        progreso->setAutoFillBackground(false);
        progreso->setValue(0);
        progreso->setOrientation(Qt::Horizontal);
        progreso->setInvertedAppearance(false);
        progreso->setTextDirection(QProgressBar::TopToBottom);

        verticalLayout_2->addWidget(progreso);

        btnSig = new QPushButton(page);
        btnSig->setObjectName(QStringLiteral("btnSig"));
        btnSig->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout_2->addWidget(btnSig);

        ventana->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        pushButton = new QPushButton(page_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(160, 300, 321, 51));
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setLayoutDirection(Qt::LeftToRight);
        cantEstaciones = new QSpinBox(page_2);
        cantEstaciones->setObjectName(QStringLiteral("cantEstaciones"));
        cantEstaciones->setGeometry(QRect(350, 240, 121, 31));
        cantEstaciones->setMinimum(1);
        cantEstaciones->setMaximum(1000);
        label = new QLabel(page_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(160, 240, 181, 41));
        label_2 = new QLabel(page_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(160, 190, 181, 41));
        cantEscritorios = new QSpinBox(page_2);
        cantEscritorios->setObjectName(QStringLiteral("cantEscritorios"));
        cantEscritorios->setGeometry(QRect(350, 190, 121, 31));
        cantEscritorios->setMinimum(1);
        cantEscritorios->setMaximum(1000);
        cantEscritorios->setValue(1);
        label_3 = new QLabel(page_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(160, 130, 181, 41));
        cantAviones = new QSpinBox(page_2);
        cantAviones->setObjectName(QStringLiteral("cantAviones"));
        cantAviones->setGeometry(QRect(350, 130, 121, 31));
        cantAviones->setMinimum(1);
        cantAviones->setMaximum(1000);
        cantAviones->setValue(1);
        label_4 = new QLabel(page_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(160, 80, 181, 41));
        cantPasos = new QSpinBox(page_2);
        cantPasos->setObjectName(QStringLiteral("cantPasos"));
        cantPasos->setGeometry(QRect(350, 80, 121, 31));
        cantPasos->setMinimum(1);
        cantPasos->setMaximum(1000);
        ventana->addWidget(page_2);

        verticalLayout->addWidget(ventana);

        Aereopuerto->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Aereopuerto);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 643, 22));
        Aereopuerto->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Aereopuerto);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        Aereopuerto->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Aereopuerto);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Aereopuerto->setStatusBar(statusBar);

        retranslateUi(Aereopuerto);

        ventana->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Aereopuerto);
    } // setupUi

    void retranslateUi(QMainWindow *Aereopuerto)
    {
        Aereopuerto->setWindowTitle(QApplication::translate("Aereopuerto", "Aereopuerto", Q_NULLPTR));
        txtImg->setText(QApplication::translate("Aereopuerto", "Imagen", Q_NULLPTR));
        consola->setPlaceholderText(QApplication::translate("Aereopuerto", "Consola", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        progreso->setStatusTip(QString());
#endif // QT_NO_STATUSTIP
        progreso->setFormat(QString());
        btnSig->setText(QApplication::translate("Aereopuerto", "Siguiente", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Aereopuerto", "Iniciar simulaci\303\263n", Q_NULLPTR));
        label->setText(QApplication::translate("Aereopuerto", "Cantidad de Estaciones", Q_NULLPTR));
        label_2->setText(QApplication::translate("Aereopuerto", "Cantidad de Escritorios", Q_NULLPTR));
        cantEscritorios->setSpecialValueText(QString());
        label_3->setText(QApplication::translate("Aereopuerto", "Cantidad de aviones", Q_NULLPTR));
        label_4->setText(QApplication::translate("Aereopuerto", "Cantidad de pasos", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Aereopuerto: public Ui_Aereopuerto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AEREOPUERTO_H
